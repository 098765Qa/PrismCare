const Visit = require('../models/Visit');
const StaffProfile = require('../models/StaffProfile');
const ClientNeeds = require('../models/supportNeeds');
const User = require('../models/User');

// Helper: classify time-of-day
function getShiftType(date) {
  const hour = new Date(date).getHours();
  if (hour >= 6 && hour < 12) return 'morning';
  if (hour >= 12 && hour < 18) return 'afternoon';
  if (hour >= 18 && hour < 23) return 'evening';
  return 'night';
}

// Estimate weekly hours already scheduled for staff
async function getScheduledHoursForWeek(staffId, weekStart, weekEnd) {
  const visits = await Visit.find({
    staff: staffId,
    plannedStart: { $gte: weekStart, $lte: weekEnd },
  }).lean();

  let totalMinutes = 0;
  for (const v of visits) {
    const start = new Date(v.plannedStart);
    const end = new Date(v.plannedEnd);
    totalMinutes += (end - start) / (1000 * 60);
  }

  return totalMinutes / 60; // hours
}

// Basic travel estimation placeholder (can integrate real API later)
function estimateTravelPenalty(staffProfile, client) {
  // For now: if no postcode info, no penalty
  if (!staffProfile?.homePostcode || !client?.postcode) return 0;
  // Very rough: if different first 3 chars of postcode, add penalty
  if (
    staffProfile.homePostcode.slice(0, 3).toUpperCase() !==
    client.postcode.slice(0, 3).toUpperCase()
  ) {
    return -10; // small penalty
  }
  return 0;
}

// Main scoring function
async function scoreStaffForVisit({ staffUser, client, plannedStart, plannedEnd }) {
  const staffProfile = await StaffProfile.findOne({ user: staffUser._id }).lean();
  const clientNeeds = await ClientNeeds.findOne({ client: client._id }).lean();

  let score = 0;
  const details = [];

  // 1) Skills matching
  if (clientNeeds?.requiredSkills?.length && staffProfile?.skills?.length) {
    const matchedSkills = clientNeeds.requiredSkills.filter(s =>
      staffProfile.skills.includes(s)
    );
    score += matchedSkills.length * 15; // each required skill match is valuable
    details.push(`Skills matched: ${matchedSkills.join(', ')}`);
  }

  // 2) Shift preference
  const shiftType = getShiftType(plannedStart);
  if (staffProfile?.preferredShiftTypes?.includes(shiftType)) {
    score += 10;
    details.push(`Prefers ${shiftType} shifts`);
  }

  // 3) Continuity: has visited this client before?
  const previousVisits = await Visit.countDocuments({
    client: client._id,
    staff: staffUser._id,
  });
  if (previousVisits > 0) {
    const continuityScore = Math.min(20, previousVisits * 2);
    score += continuityScore;
    details.push(`Continuity: ${previousVisits} previous visits`);
  }

  // 4) Preferred client list
  if (staffProfile?.preferredClients?.some(
    c => c.toString() === client._id.toString()
  )) {
    score += 10;
    details.push('Client in staff preferred list');
  }

  // 5) Fatigue / weekly hours
  const weekStart = new Date(plannedStart);
  weekStart.setDate(weekStart.getDate() - weekStart.getDay()); // Sunday
  weekStart.setHours(0, 0, 0, 0);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);

  const currentHours = await getScheduledHoursForWeek(staffUser._id, weekStart, weekEnd);
  const maxHours = staffProfile?.maxWeeklyHours || 40;
  if (currentHours > maxHours) {
    score -= 40; // overload
    details.push(`Over max weekly hours (${currentHours.toFixed(1)}h)`);
  } else if (currentHours > maxHours * 0.8) {
    score -= 10;
    details.push(`Near max weekly hours (${currentHours.toFixed(1)}h)`);
  } else {
    score += 5;
    details.push(`Healthy workload (${currentHours.toFixed(1)}h)`);
  }

  // 6) Travel penalty
  const travelPenalty = estimateTravelPenalty(staffProfile, client);
  if (travelPenalty !== 0) {
    score += travelPenalty;
    details.push('Travel penalty applied based on postcode');
  }

  // 7) Double-up prediction
  // If client usually needs double-up and this staff has 'double_up' skill, reward
  if (clientNeeds?.usuallyDoubleUp && staffProfile?.skills?.includes('double_up')) {
    score += 10;
    details.push('Suitable for double-up care');
  }

  return { staff: staffUser, score, details };
}

// Suggest staff for a single visit window
async function suggestStaffForVisit({ clientId, plannedStart, plannedEnd }) {
  const client = await Client.findById(clientId).lean();
  if (!client) throw new Error('Client not found');

  const staffUsers = await User.find({ role: 'staff', isActive: true }).lean();

  const scored = [];
  for (const staffUser of staffUsers) {
    const result = await scoreStaffForVisit({ staffUser, client, plannedStart, plannedEnd });
    scored.push(result);
  }

  // Sort best to worst
  scored.sort((a, b) => b.score - a.score);

  return scored;
}

module.exports = {
  suggestStaffForVisit,
};