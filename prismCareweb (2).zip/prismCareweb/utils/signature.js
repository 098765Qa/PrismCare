const DigitalSignature = require('../models/DigitalSignature');

async function saveSignature({ user, entityType, entityId, signatureData, ip }) {
  return await DigitalSignature.create({
    user: user._id,
    entityType,
    entityId,
    signatureData,
    ip
  });
}

module.exports = saveSignature;