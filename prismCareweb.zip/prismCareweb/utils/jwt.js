const jwt = require('jsonwebtoken');
const RefreshToken = require('../models/RefreshToken');

const ACCESS_TOKEN_EXPIRES_IN = '15m';   // A1
const REFRESH_TOKEN_EXPIRES_IN_DAYS = 7; // R1

function signAccessToken(user) {
  return jwt.sign(
    {
      sub: user._id.toString(),
      role: user.role
    },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: ACCESS_TOKEN_EXPIRES_IN }
  );
}

function signRefreshToken(user) {
  const expires = new Date();
  expires.setDate(expires.getDate() + REFRESH_TOKEN_EXPIRES_IN_DAYS);

  const token = jwt.sign(
    {
      sub: user._id.toString()
    },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: `${REFRESH_TOKEN_EXPIRES_IN_DAYS}d` }
  );

  return { token, expiresAt: expires };
}

function verifyAccessToken(token) {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
}

async function createRefreshToken(user, ip, userAgent) {
  const { token, expiresAt } = signRefreshToken(user);

  const refreshToken = await RefreshToken.create({
    user: user._id,
    token,
    expiresAt,
    createdByIp: ip,
    userAgent
  });

  return refreshToken;
}

async function revokeRefreshToken(token, ip) {
  const doc = await RefreshToken.findOne({ token, revoked: false });
  if (!doc) return;

  doc.revoked = true;
  doc.revokedAt = new Date();
  doc.revokedByIp = ip;
  await doc.save();
}

async function rotateRefreshToken(oldToken, ip, userAgent) {
  const existing = await RefreshToken.findOne({ token: oldToken, revoked: false }).populate('user');
  if (!existing) throw new Error('Invalid refresh token');

  existing.revoked = true;
  existing.revokedAt = new Date();
  existing.revokedByIp = ip;
  await existing.save();

  const newRefreshToken = await createRefreshToken(existing.user, ip, userAgent);
  const newAccessToken = signAccessToken(existing.user);

  return { newRefreshToken, newAccessToken, user: existing.user };
}

module.exports = {
  signAccessToken,
  verifyAccessToken,
  verifyRefreshToken,
  createRefreshToken,
  revokeRefreshToken,
  rotateRefreshToken
};